#Frontend estatico para el proyecto final del curso Bases de Datos Desde Cero

Estilos y layout para el proyecto del curso Bases de Datos Desde Cero http://escueladigital.pe/sql dictado por Alexys Lozada.
