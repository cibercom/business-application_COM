<?php
//views/editarCliente.php

class editarCliente extends Views{
    public $cliente;
    public $rol;
}
?>