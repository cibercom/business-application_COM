<?php
//views//listadoUsuarios.php

class listadoUsuarios extends Views{
    public $usuario;
    public $rol2;
    public $rol;
}
?>