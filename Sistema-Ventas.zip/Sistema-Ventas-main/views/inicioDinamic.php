<?php
//views//inicioDinamic.php

class inicioDinamic extends Views{
    public $clicant; 
    public $provcant; 
    public $prodcant; 
    public $comcant; 
    public $pedcant;
    public $repcant; 
    public $usucant;
    public $pedtot; 
    public $rol; 
}
?>