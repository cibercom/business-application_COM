<?php
//views/Login.php
class Login extends Views{
}
?>