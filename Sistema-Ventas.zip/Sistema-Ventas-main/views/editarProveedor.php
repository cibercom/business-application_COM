<?php
//views/editarProveedor.php

class editarProveedor extends Views{
    public $proveedor;
    public $rol;
}
?>