<?php
//views//listadoProductos.php

class listadoProductos extends Views{
    public $producto;
    public $rol;
}
?>