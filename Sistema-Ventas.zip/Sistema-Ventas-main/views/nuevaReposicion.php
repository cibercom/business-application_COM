<?php
//views/nuevaReposicion.php

class nuevaReposicion extends Views{
    public $rol;
}
?>