<?php
//views/nuevaCompra.php

class nuevaCompra extends Views{
    public $rol;
}
?>