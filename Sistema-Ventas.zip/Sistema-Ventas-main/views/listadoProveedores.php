<?php
//views//listadoProveedores.php

class listadoProveedores extends Views{
    public $proveedor;
    public $rol;
}
?>