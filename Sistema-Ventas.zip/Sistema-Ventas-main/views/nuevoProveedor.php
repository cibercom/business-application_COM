<?php
//views/nuevoProveedor.php

class nuevoProveedor extends Views{
    public $rol;
}
?>