<?php
//views//listadoPedidos.php

class listadoPedidos extends Views{
    public $pedido;
    public $total_paginas;
    public $pagina;
    public $estado;
    public $rol;
}
?>