<?php
//views//listadoCompras.php

class listadoCompras extends Views{
    public $compra;
    public $proveedores;
    public $total_paginas;
    public $pagina;
    public $estado;
    public $rol;
}
?>