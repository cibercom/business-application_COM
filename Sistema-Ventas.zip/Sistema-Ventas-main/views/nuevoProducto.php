<?php
//views/nuevoProducto.php

class nuevoProducto extends Views{
    public $rol;
}
?>