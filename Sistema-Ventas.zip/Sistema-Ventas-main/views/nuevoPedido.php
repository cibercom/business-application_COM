<?php
//views/nuevoPedido.php

class nuevoPedido extends Views{
    public $resultado_iva;
    public $resultado;
    public $dni_cliente;
    public $id_cliente;
    public $rol;
}
?>