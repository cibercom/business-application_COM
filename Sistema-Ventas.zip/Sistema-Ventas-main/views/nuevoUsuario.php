<?php
//views/nuevoUsuario.php

class nuevoUsuario extends Views{
    public $rol2;
    public $rol;
}
?>