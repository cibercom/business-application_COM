<?php
//views//listadoClientes.php

class listadoClientes extends Views{
    public $clientes;
    public $rol;

}
?>