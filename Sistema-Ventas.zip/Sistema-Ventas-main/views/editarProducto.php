<?php
//views/editarProducto.php

class editarProducto extends Views{
    public $producto;
    public $rol;
}
?>