<?php
//views/editarCompra.php

class editarCompra extends Views{
    public $compra;
    public $proveedores;
    public $rol;
}
?>