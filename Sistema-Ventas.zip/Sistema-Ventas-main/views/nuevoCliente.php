<?php
//views/nuevoCliente.php

class nuevoCliente extends Views{
    public $rol;
}
?>