<?php
//views/editarUsuario.php

class editarUsuario extends Views{
    public $usuario;
    public $rol2;
    public $rol;
}
?>