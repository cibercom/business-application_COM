<?php
// Authentication of database server
$servername = "127.0.0.1";
$username = "root";
$password = "";
// Create connection
$conn = new mysqli($servername, $username, $password);
// Check connection
if ($conn->connect_error)
{
    die("Fault in connection: " . $conn->connect_error);
}
// Create database
$sql = "CREATE DATABASE test_db";
if ($conn->query($sql) === TRUE)
{
    echo "Database created.";
}
else
{
    die("Fault in creating database: " . $conn->error);
}
$conn->close();
?>