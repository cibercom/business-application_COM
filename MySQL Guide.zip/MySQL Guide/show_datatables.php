<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "test_db";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error)
{
    die("Fault in connection: " . $conn->connect_error);
}
// Show tables
$sql = "SHOW TABLES";
$result = $conn->query($sql);
if($result)
{
    echo "Tables in database test_db:<br>";
    while($row = mysqli_fetch_assoc($result))
    {
        echo $row["Tables_in_test_db"]. "<br>";
    }
}
else
{
    echo "None.";
}
$conn->close();
?>