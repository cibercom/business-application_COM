<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "test_db";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error)
{
    die("Fault in connection: " . $conn->connect_error);
}
// Create data table
$sql = "CREATE TABLE TestTable (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
email VARCHAR(50),
reg_date TIMESTAMP
)";
if ($conn->query($sql) === TRUE)
{
    echo "Data table created.";
}
else
{
    echo "Fault in creating table: " . $conn->error;
}
$conn->close();
?>