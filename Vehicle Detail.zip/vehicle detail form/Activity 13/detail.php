<?php
$error = '';
$model = '';
$manufacturer = '';
$color = '';
$year_built = '';
$showDetails = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $model = $_POST['model'];
    $manufacturer = $_POST['manufacturer'];
    $color = $_POST['color'];
    $year_built = $_POST['year_built'];

    // Validate form inputs
    if (empty($model) || empty($manufacturer) || empty($color) || empty($year_built)) {
        $error = 'Please complete all fields.';
        $model = empty($model) ? '!' : $model;
        $manufacturer = empty($manufacturer) ? '!' : $manufacturer;
        $color = empty($color) ? '!' : $color;
        $year_built = empty($year_built) ? '!' : $year_built;
    } elseif (!is_numeric($year_built) || $year_built < 1900 || $year_built > date('Y')) {
        $error = 'Please enter a valid year.';
    } else {
        // All inputs are valid
        $showDetails = true;
    }
}

if (isset($_POST['clear_btn'])) {
    $model = '';
    $manufacturer = '';
    $color = '';
    $year_built = '';
    $showDetails = false;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Vehicle Details Form</title>
    <link rel="stylesheet" type="text/css" href="script/css/design.css">

</head>
<body>
    <h1>Vehicle Details Form</h1>

    <?php if (!empty($error)) : ?>
        <div class="form-error"><?php echo $error; ?></div>
    <?php endif; ?>

    <form id="vehicle_form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <div class="form-group">
            <label for="model">Model:</label>
            <input type="text" id="model" name="model" value="<?php echo $model; ?>">
            <?php if ($model === '!') : ?>
                <span class="warning">!</span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="manufacturer">Manufacturer:</label>
            <input type="text" id="manufacturer" name="manufacturer" value="<?php echo $manufacturer; ?>">
            <?php if ($manufacturer === '!') : ?>
                <span class="warning">!</span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="color">Color:</label>
            <input type="text" id="color" name="color" value="<?php echo $color; ?>">
            <?php if ($color === '!') : ?>
                <span class="warning">!</span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="year_built">Year Built:</label>
            <input type="number" id="year_built" name="year_built" value="<?php echo $year_built; ?>">
            <?php if ($year_built === '!') : ?>
                <span class="warning">!</span>
            <?php endif; ?>
        </div>
        <button type="submit" id="submit_btn" name="submit_btn">Submit</button>
        <button type="submit" id="clear_btn" name="clear_btn">Clear</button>
    </form>

    <?php if ($showDetails) : ?>
        <div class="vehicle-details">
            <h2>Vehicle Details:</h2>
            <p><strong>Model:</strong> <?php echo $model; ?></p>
            <p><strong>Manufacturer:</strong> <?php echo $manufacturer; ?></p>
            <p><strong>Color:</strong> <?php echo $color; ?></p>
            <p><strong>Year Built:</strong> <?php echo $year_built; ?></p>
        </div>
    <?php endif; ?>

    <script>
        document.getElementById('clear_btn').addEventListener('click', function() {
            document.getElementById('vehicle_form').reset();
        });
    </script>
</body>
</html>